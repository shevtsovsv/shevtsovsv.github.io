"""
Арканоид на Pygame — версия для pygbag (запуск в браузере).

Как собрать:
    1. Сохраните файл как main.py
    2. Установите pygbag:  pip install pygbag
    3. В папке с файлом запустите:  pygbag .
    4. Откройте http://localhost:8000

На десктопе (Windows/Linux/macOS) запускается как обычно: python main.py
"""
import sys
import asyncio
import random

# --- Заплатка для Windows DPI (только на десктопе; в браузере пропускается) ---
if sys.platform == 'win32':
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
    except Exception:
        pass

import pygame

# ==================== КОНСТАНТЫ ====================
WIDTH = 600
HEIGHT = 600
FPS = 60

FIELD_LEFT = 40
FIELD_RIGHT = WIDTH - 40
FIELD_TOP = 40

PADDLE_W = 100
PADDLE_H = 15
BALL_SIZE = 16
PADDLE_SPEED = 8
BALL_SPEED = 5

MAX_PADDLE_W = 180
MIN_PADDLE_W = 60

# --- Кирпичи ---
BRICK_H = 22
BRICK_GAP = 4
BRICK_START_X = FIELD_LEFT + 12
BRICK_START_Y = FIELD_TOP + 30

ROW_COLORS = [
    (255, 60, 60),
    (255, 165, 0),
    (255, 230, 0),
    (80, 220, 80),
    (80, 180, 255),
]

# --- Уровни ---
LEVELS = [
    [
        "11111111",
        "22222222",
        "33333333",
        "44444444",
        "55555555",
    ],
    [
        "00011000",
        "00111100",
        "01111110",
        "11111111",
        "44444444",
    ],
    [
        "10101010",
        "02020202",
        "30303030",
        "04040404",
        "50505050",
        "10101010",
    ],
]

# --- Бонусы ---
BONUS_TYPES = ['expand', 'life', 'slow']
BONUS_COLORS = {
    'expand': (100, 255, 100),
    'life':   (255, 100, 100),
    'slow':   (100, 150, 255),
}
BONUS_LETTERS = {
    'expand': 'E',
    'life':   '+',
    'slow':   'S',
}
BONUS_SIZE = 22
BONUS_CHANCE = 0.25
BONUS_FALL_SPEED = 3

# --- Цвета оформления ---
BG_COLOR = (20, 20, 40)
FIELD_BORDER = (80, 80, 120)
BRICK_BORDER = (255, 255, 255)
PADDLE_COLOR = (200, 200, 255)
BALL_COLOR = (255, 255, 100)
TEXT_COLOR = (255, 255, 255)
TEXT_HINT = (120, 120, 150)
TEXT_YELLOW = (255, 255, 0)
TEXT_GOLD = (255, 215, 0)
TEXT_RED = (255, 0, 0)


# ==================== СОСТОЯНИЕ ====================
paddle = pygame.Rect(WIDTH // 2 - PADDLE_W // 2, HEIGHT - 60, PADDLE_W, PADDLE_H)
ball = pygame.Rect(WIDTH // 2 - BALL_SIZE // 2, HEIGHT - 80, BALL_SIZE, BALL_SIZE)

vx = BALL_SPEED
vy = -BALL_SPEED

bricks = []
bonuses = []
current_level = 0
score = 0
lives = 3
state = 'ready'  # ready | playing | won | lost


# ==================== ЛОГИКА ====================

def load_level(index):
    """Загрузить раскладку уровня — пересобрать список кирпичей."""
    global bricks
    bricks = []
    layout = LEVELS[index]
    rows = len(layout)
    cols = len(layout[0])

    available = FIELD_RIGHT - FIELD_LEFT - 24
    bw = (available - (cols - 1) * BRICK_GAP) // cols

    for row in range(rows):
        line = layout[row]
        for col in range(cols):
            ch = line[col]
            if ch == '0':
                continue
            color_idx = int(ch) - 1
            if color_idx < 0 or color_idx >= len(ROW_COLORS):
                color_idx = 0
            x = BRICK_START_X + col * (bw + BRICK_GAP)
            y = BRICK_START_Y + row * (BRICK_H + BRICK_GAP)
            bricks.append({
                'rect': pygame.Rect(x, y, bw, BRICK_H),
                'color': ROW_COLORS[color_idx],
                'alive': True,
            })


def hold_ball_on_paddle():
    ball.centerx = paddle.centerx
    ball.bottom = paddle.top


def any_brick_alive():
    for b in bricks:
        if b['alive']:
            return True
    return False


def reset_ball():
    global vx, vy, state
    vx = BALL_SPEED
    vy = -BALL_SPEED
    state = 'ready'


def apply_bonus(btype):
    global lives, vx, vy
    if btype == 'expand':
        old_center = paddle.centerx
        paddle.width = min(paddle.width + 30, MAX_PADDLE_W)
        paddle.centerx = old_center
        if paddle.left < FIELD_LEFT:
            paddle.left = FIELD_LEFT
        if paddle.right > FIELD_RIGHT:
            paddle.right = FIELD_RIGHT
    elif btype == 'life':
        if lives < 5:
            lives += 1
    elif btype == 'slow':
        new_vx = vx * 0.8
        new_vy = vy * 0.8
        if abs(new_vx) >= 2:
            vx = new_vx
        if abs(new_vy) >= 2:
            vy = new_vy


def advance_level():
    global current_level, state, vx, vy
    if current_level < len(LEVELS) - 1:
        current_level += 1
        load_level(current_level)
        bonuses.clear()
        paddle.centerx = WIDTH // 2
        paddle.width = PADDLE_W
        vx = BALL_SPEED
        vy = -BALL_SPEED
        state = 'ready'
    else:
        state = 'won'


def restart_game():
    global score, lives, state, current_level, vx, vy
    score = 0
    lives = 3
    state = 'ready'
    current_level = 0
    load_level(0)
    bonuses.clear()
    paddle.centerx = WIDTH // 2
    paddle.width = PADDLE_W
    vx = BALL_SPEED
    vy = -BALL_SPEED
    hold_ball_on_paddle()


def check_brick_collision():
    """Проверить столкновение мяча с кирпичами. Определить сторону удара."""
    global vx, vy, score
    for b in bricks:
        if not b['alive']:
            continue
        if not ball.colliderect(b['rect']):
            continue

        b['alive'] = False
        score += 10

        # Шанс выпадения бонуса
        if random.random() < BONUS_CHANCE:
            btype = random.choice(BONUS_TYPES)
            bx = b['rect'].centerx - BONUS_SIZE // 2
            by = b['rect'].centery
            bonuses.append({
                'rect': pygame.Rect(bx, by, BONUS_SIZE, BONUS_SIZE),
                'type': btype,
            })

        # Определяем, с какой стороны мяч попал — по минимальному перекрытию
        r = b['rect']
        overlap_x = min(ball.right, r.right) - max(ball.left, r.left)
        overlap_y = min(ball.bottom, r.bottom) - max(ball.top, r.top)
        if overlap_x < overlap_y:
            vx = -vx
        else:
            vy = -vy

        if not any_brick_alive():
            advance_level()

        return True
    return False


def update_bonuses():
    """Опустить бонусы вниз, обработать подбор ракеткой."""
    for bonus in bonuses:
        bonus['rect'].y += BONUS_FALL_SPEED
        if bonus['rect'].colliderect(paddle):
            apply_bonus(bonus['type'])
            bonus['rect'].y = HEIGHT + 100
        elif bonus['rect'].top > HEIGHT:
            bonus['rect'].y = HEIGHT + 100
    bonuses[:] = [b for b in bonuses if b['rect'].top < HEIGHT]


def update_playing(dt):
    """Обновление во время игры — движение мяча, столкновения, бонусы."""
    global vx, vy, lives, state

    # Движение мяча
    ball.x += vx
    ball.y += vy

    # Отскоки от стен
    if ball.left < FIELD_LEFT:
        vx = -vx
        ball.left = FIELD_LEFT
    if ball.right > FIELD_RIGHT:
        vx = -vx
        ball.right = FIELD_RIGHT
    if ball.top < FIELD_TOP:
        vy = -vy
        ball.top = FIELD_TOP

    check_brick_collision()
    update_bonuses()

    # Отскок от ракетки
    if ball.colliderect(paddle) and vy > 0:
        vy = -vy
        ball.bottom = paddle.top

    # Потеря жизни — мяч улетел вниз
    if ball.top > HEIGHT:
        lives -= 1
        bonuses.clear()
        paddle.width = PADDLE_W
        if lives <= 0:
            state = 'lost'
        else:
            reset_ball()
            paddle.centerx = WIDTH // 2


def update_paddle():
    """Движение ракетки стрелками/A/D. Работает в 'ready' и 'playing'."""
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        paddle.x -= PADDLE_SPEED
    if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        paddle.x += PADDLE_SPEED
    if paddle.left < FIELD_LEFT:
        paddle.left = FIELD_LEFT
    if paddle.right > FIELD_RIGHT:
        paddle.right = FIELD_RIGHT


# ==================== РИСОВАНИЕ ====================

def render_text(surface, text, font, color, pos, center=False):
    """Универсальная функция: рисует текст по левому верхнему углу или по центру."""
    surf = font.render(text, True, color)
    if center:
        rect = surf.get_rect(center=pos)
    else:
        rect = surf.get_rect(topleft=pos)
    surface.blit(surf, rect)


def draw_game(screen, fonts):
    screen.fill(BG_COLOR)

    # Рамка вокруг игрового поля
    pygame.draw.rect(
        screen, FIELD_BORDER,
        (FIELD_LEFT - 2, FIELD_TOP - 2,
         FIELD_RIGHT - FIELD_LEFT + 4,
         HEIGHT - FIELD_TOP + 2),
        2
    )

    # Кирпичи
    for b in bricks:
        if b['alive']:
            pygame.draw.rect(screen, b['color'], b['rect'])
            pygame.draw.rect(screen, BRICK_BORDER, b['rect'], 1)

    # Бонусы
    for bonus in bonuses:
        color = BONUS_COLORS[bonus['type']]
        pygame.draw.rect(screen, color, bonus['rect'])
        pygame.draw.rect(screen, (0, 0, 0), bonus['rect'], 1)
        render_text(
            screen, BONUS_LETTERS[bonus['type']], fonts['bonus'],
            (0, 0, 0), bonus['rect'].center, center=True
        )

    # Ракетка и мяч
    pygame.draw.rect(screen, PADDLE_COLOR, paddle)
    pygame.draw.rect(screen, BALL_COLOR, ball)

    # HUD сверху
    render_text(screen, f"Счёт: {score}", fonts['hud'], TEXT_COLOR, (FIELD_LEFT, 10))
    render_text(screen, f"Жизни: {lives}", fonts['hud'], TEXT_COLOR, (FIELD_RIGHT - 90, 10))
    render_text(
        screen, f"Уровень: {current_level + 1}/{len(LEVELS)}",
        fonts['hud'], TEXT_COLOR, (WIDTH // 2 - 65, 10)
    )

    # Подсказки снизу
    if state == 'ready':
        render_text(
            screen, "Нажми ПРОБЕЛ, чтобы запустить",
            fonts['hint'], TEXT_YELLOW, (WIDTH // 2, HEIGHT - 25), center=True
        )
    elif state == 'playing':
        render_text(
            screen, "← → или A D",
            fonts['hint'], TEXT_HINT, (WIDTH // 2, HEIGHT - 25), center=True
        )

    # Экран победы
    if state == 'won':
        render_text(screen, "ПОБЕДА!", fonts['big'], TEXT_GOLD,
                    (WIDTH // 2, HEIGHT // 2 - 50), center=True)
        render_text(screen, f"Все {len(LEVELS)} уровня пройдены!",
                    fonts['medium'], TEXT_COLOR,
                    (WIDTH // 2, HEIGHT // 2), center=True)
        render_text(screen, f"Твой счёт: {score}", fonts['large'], TEXT_YELLOW,
                    (WIDTH // 2, HEIGHT // 2 + 50), center=True)
        render_text(screen, "Нажми R для новой игры", fonts['hint'], TEXT_COLOR,
                    (WIDTH // 2, HEIGHT // 2 + 110), center=True)

    # Экран поражения
    if state == 'lost':
        render_text(screen, "ИГРА ОКОНЧЕНА", fonts['big'], TEXT_RED,
                    (WIDTH // 2, HEIGHT // 2 - 50), center=True)
        render_text(screen, f"Твой счёт: {score}", fonts['large'], TEXT_COLOR,
                    (WIDTH // 2, HEIGHT // 2 + 20), center=True)
        render_text(screen, "Нажми R для новой игры", fonts['hint'], TEXT_YELLOW,
                    (WIDTH // 2, HEIGHT // 2 + 80), center=True)


# ==================== ГЛАВНЫЙ ЦИКЛ ====================

async def main():
    global state, vx, vy

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Арканоид")
    clock = pygame.time.Clock()

    # Шрифты (встроенный freesansbold поддерживает кириллицу)
    fonts = {
        'hud':    pygame.font.Font(None, 22),
        'hint':   pygame.font.Font(None, 20),
        'bonus':  pygame.font.Font(None, 20),
        'medium': pygame.font.Font(None, 26),
        'large':  pygame.font.Font(None, 34),
        'big':    pygame.font.Font(None, 66),
    }

    load_level(0)
    hold_ball_on_paddle()

    running = True
    while running:
        clock.tick(FPS)

        # ---------- События ----------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                # SPACE — запуск мяча
                if event.key == pygame.K_SPACE and state == 'ready':
                    vx = random.choice([-1, 1]) * BALL_SPEED
                    vy = -BALL_SPEED
                    state = 'playing'
                # R — перезапуск на финальных экранах
                elif event.key == pygame.K_r and state in ('won', 'lost'):
                    restart_game()

        # ---------- Логика ----------
        if state in ('ready', 'playing'):
            update_paddle()

        if state == 'ready':
            hold_ball_on_paddle()
        elif state == 'playing':
            update_playing(0)

        # ---------- Рисование ----------
        draw_game(screen, fonts)
        pygame.display.flip()

        # Обязательно для pygbag — отдать управление браузеру
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())