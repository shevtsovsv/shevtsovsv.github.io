"""
Doodle Jump на Pygame — версия для pygbag (запуск в браузере).

Как собрать:
    1. Сохраните файл как main.py
    2. Установите pygbag:  pip install pygbag
    3. В папке с файлом запустите:  pygbag .
    4. Откройте http://localhost:8000

На десктопе (Windows/Linux/macOS) запускается как обычно: python main.py
"""
import sys
import asyncio
import random

# --- Заплатка для Windows DPI (только на десктопе; в браузере пропускается) ---
if sys.platform == 'win32':
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
    except Exception:
        pass

import pygame

# ==================== КОНСТАНТЫ ====================
WIDTH = 400
HEIGHT = 600
FPS = 60

# --- Физика (значения на 1 кадр при 60 FPS) ---
GRAVITY = 0.5
JUMP_POWER = 14

# --- Горизонтальное движение ---
ACCELERATION = 0.6
FRICTION = 0.85
MAX_SPEED = 7

# --- Персонаж ---
PLAYER_W = 30
PLAYER_H = 30

# --- Платформы ---
PLATFORM_W = 70
PLATFORM_H = 15
PLATFORM_GAP = 80

# --- Скроллинг ---
SCROLL_LINE = HEIGHT // 3

# --- Цвета платформ ---
PLATFORM_COLORS = {
    'normal':   ((100, 200, 100), (50, 120, 50)),
    'moving':   ((100, 150, 240), (50, 80, 180)),
    'breaking': ((180, 130, 80), (120, 80, 40)),
    'spring':   ((255, 150, 200), (200, 80, 140)),
}

# --- Враги ---
ENEMY_SIZE = 26
ENEMY_SPEED = 2
ENEMY_CHANCE = 0.2

# --- Бонусы ---
BONUS_SIZE = 24
BONUS_CHANCE = 0.15
BONUS_COLORS = {
    'shield': (100, 200, 255),
    'rocket': (255, 100, 100),
}
BONUS_LETTERS = {
    'shield': 'S',
    'rocket': 'R',
}

# --- Цвета оформления ---
BG_COLOR = (240, 240, 255)
TEXT_DARK = (50, 50, 50)
TEXT_GRAY = (120, 120, 120)
TEXT_LIGHT = (200, 200, 200)
TEXT_WHITE = (255, 255, 255)
TEXT_YELLOW = (255, 255, 0)
TEXT_GOLD = (255, 215, 0)
TEXT_SHIELD = (100, 200, 255)
TEXT_ROCKET = (255, 100, 100)
TEXT_RECORD = (255, 100, 100)

# ==================== СОСТОЯНИЕ ====================
player = pygame.Rect(WIDTH // 2 - PLAYER_W // 2, HEIGHT // 2, PLAYER_W, PLAYER_H)
vy = 0
vx = 0

platforms = []
enemies = []
bonuses = []

score = 0
highscore = 0
state = 'ready'          # 'ready' | 'playing' | 'lost'
new_record = False

has_shield = False
rocket_timer = 0.0


# ==================== ФАЙЛ РЕКОРДА ====================
# Внимание: в pygbag файловая система виртуальная (в памяти).
# Файл будет жить до перезагрузки страницы. На десктопе — обычный файл.

def load_highscore():
    global highscore
    try:
        with open("highscore.txt", "r") as f:
            highscore = int(f.read())
    except Exception:
        highscore = 0


def save_highscore():
    try:
        with open("highscore.txt", "w") as f:
            f.write(str(int(highscore)))
    except Exception:
        pass


# ==================== СОЗДАНИЕ ОБЪЕКТОВ ====================

def make_platform(x, y, force_type=None):
    if force_type is None:
        r = random.random()
        if r < 0.6:
            ptype = 'normal'
        elif r < 0.75:
            ptype = 'moving'
        elif r < 0.9:
            ptype = 'breaking'
        else:
            ptype = 'spring'
    else:
        ptype = force_type

    p = {
        'rect': pygame.Rect(x, y, PLATFORM_W, PLATFORM_H),
        'type': ptype,
        'vx': 0,
        'broken': False,
        'respawn_timer': 0,
    }
    if ptype == 'moving':
        p['vx'] = random.choice([-2, 2])
    return p


def make_enemy(x, y):
    return {
        'rect': pygame.Rect(x, y, ENEMY_SIZE, ENEMY_SIZE),
        'vx': random.choice([-ENEMY_SPEED, ENEMY_SPEED]),
    }


def make_bonus(x, y):
    btype = random.choice(['shield', 'rocket'])
    return {
        'rect': pygame.Rect(x, y, BONUS_SIZE, BONUS_SIZE),
        'type': btype,
    }


def spawn_initial():
    platforms.clear()
    enemies.clear()
    bonuses.clear()

    ground = {
        'rect': pygame.Rect(0, HEIGHT - 60, WIDTH, PLATFORM_H),
        'type': 'normal',
        'vx': 0,
        'broken': False,
        'respawn_timer': 0,
    }
    platforms.append(ground)

    y = HEIGHT - 60
    while y > -PLATFORM_GAP:
        y -= PLATFORM_GAP + random.randint(-20, 40)
        x = random.randint(0, WIDTH - PLATFORM_W)
        platforms.append(make_platform(x, y))


def ensure_platforms_above():
    if not platforms:
        return
    top_y = min(p['rect'].y for p in platforms)
    while top_y > -PLATFORM_GAP:
        top_y -= PLATFORM_GAP + random.randint(-20, 40)
        x = random.randint(0, WIDTH - PLATFORM_W)
        platforms.append(make_platform(x, top_y))

        if random.random() < ENEMY_CHANCE:
            ex = random.randint(0, WIDTH - ENEMY_SIZE)
            ey = top_y - random.randint(30, 60)
            enemies.append(make_enemy(ex, ey))

        if random.random() < BONUS_CHANCE:
            bx = random.randint(0, WIDTH - BONUS_SIZE)
            by = top_y - random.randint(60, 120)
            bonuses.append(make_bonus(bx, by))


# ==================== ОБНОВЛЕНИЕ ====================

def update_platforms(dt, factor):
    for p in platforms:
        if p['type'] == 'moving' and not p['broken']:
            p['rect'].x += p['vx'] * factor
            if p['rect'].left < 0:
                p['rect'].left = 0
                p['vx'] = -p['vx']
            elif p['rect'].right > WIDTH:
                p['rect'].right = WIDTH
                p['vx'] = -p['vx']

        if p['type'] == 'breaking' and p['broken']:
            p['respawn_timer'] -= dt
            if p['respawn_timer'] <= 0:
                p['broken'] = False
                p['respawn_timer'] = 0


def update_enemies(factor):
    for e in enemies:
        e['rect'].x += e['vx'] * factor
        if e['rect'].left < 0:
            e['rect'].left = 0
            e['vx'] = -e['vx']
        elif e['rect'].right > WIDTH:
            e['rect'].right = WIDTH
            e['vx'] = -e['vx']


def check_enemy_collisions():
    global has_shield
    for i in range(len(enemies) - 1, -1, -1):
        e = enemies[i]
        if player.colliderect(e['rect']):
            if has_shield:
                has_shield = False
                enemies.pop(i)
            else:
                game_over()
                return


def check_bonus_collisions():
    global has_shield, rocket_timer
    for i in range(len(bonuses) - 1, -1, -1):
        b = bonuses[i]
        if player.colliderect(b['rect']):
            if b['type'] == 'shield':
                has_shield = True
            elif b['type'] == 'rocket':
                rocket_timer = 5.0
            bonuses.pop(i)


def reset_player():
    global vy, vx
    player.centerx = WIDTH // 2
    player.bottom = HEIGHT - 60
    vy = 0
    vx = 0


def game_over():
    global state, highscore, new_record
    state = 'lost'
    if score > highscore:
        highscore = score
        new_record = True
        save_highscore()


def restart_game():
    global state, score, vy, vx, new_record, has_shield, rocket_timer
    state = 'ready'
    score = 0
    vy = 0
    vx = 0
    new_record = False
    has_shield = False
    rocket_timer = 0.0
    spawn_initial()
    reset_player()


def update(dt):
    global vy, vx, score, rocket_timer

    if state != 'playing':
        return

    # Множитель для физики: 1.0 при 60 FPS
    factor = dt * 60

    # Таймер ракеты
    if rocket_timer > 0:
        rocket_timer -= dt
        if rocket_timer < 0:
            rocket_timer = 0

    # Горизонтальное управление
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        vx -= ACCELERATION * factor
    elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        vx += ACCELERATION * factor
    else:
        # Трение — экспоненциальное, компенсируем разный frame rate
        vx *= FRICTION ** factor

    if vx > MAX_SPEED:
        vx = MAX_SPEED
    elif vx < -MAX_SPEED:
        vx = -MAX_SPEED
    if abs(vx) < 0.1:
        vx = 0

    player.x += vx * factor

    # Обёртка экрана
    if player.right < 0:
        player.left = WIDTH - 1
    elif player.left > WIDTH:
        player.right = 1

    # Вертикальная физика
    vy += GRAVITY * factor
    player.y += vy * factor

    # Платформы и враги
    update_platforms(dt, factor)
    update_enemies(factor)

    # Отскок от платформ (только если падаем вниз)
    if vy > 0:
        for p in platforms:
            if p['broken']:
                continue
            r = p['rect']
            # Игрок должен быть НАД платформой и пересекаться по X
            if (player.colliderect(r)
                    and player.bottom <= r.top + 15):
                if rocket_timer > 0:
                    vy = -JUMP_POWER * 2.0
                elif p['type'] == 'spring':
                    vy = -JUMP_POWER * 1.5
                else:
                    vy = -JUMP_POWER
                player.bottom = r.top

                if p['type'] == 'breaking':
                    p['broken'] = True
                    p['respawn_timer'] = 2.0

                break

    # Столкновения с врагами и бонусами
    check_enemy_collisions()
    if state != 'playing':
        return
    check_bonus_collisions()

    # Скроллинг мира
    if player.top < SCROLL_LINE:
        offset = SCROLL_LINE - player.top
        player.top = SCROLL_LINE
        for p in platforms:
            p['rect'].y += offset
        for e in enemies:
            e['rect'].y += offset
        for b in bonuses:
            b['rect'].y += offset
        score += offset

    # Генерация новых платформ сверху
    ensure_platforms_above()

    # Удаление ушедших вниз
    platforms[:] = [p for p in platforms if p['rect'].y < HEIGHT + 100]
    enemies[:] = [e for e in enemies if e['rect'].y < HEIGHT + 100]
    bonuses[:] = [b for b in bonuses if b['rect'].y < HEIGHT + 100]

    # Падение — проигрыш
    if player.top > HEIGHT:
        game_over()


# ==================== РИСОВАНИЕ ====================

def render_text(surface, text, font, color, pos, center=False):
    surf = font.render(text, True, color)
    if center:
        rect = surf.get_rect(center=pos)
    else:
        rect = surf.get_rect(topleft=pos)
    surface.blit(surf, rect)


def draw_player(screen):
    color = (100, 100, 255)
    border = (40, 40, 180)

    pygame.draw.rect(screen, color, player)
    pygame.draw.rect(screen, border, player, 2)

    # Двойник слева (когда игрок «обёрнулся» вправо)
    if player.right > WIDTH:
        ghost = pygame.Rect(player.x - WIDTH, player.y, PLAYER_W, PLAYER_H)
        pygame.draw.rect(screen, color, ghost)
        pygame.draw.rect(screen, border, ghost, 2)

    # Двойник справа (когда игрок «обёрнулся» влево)
    if player.left < 0:
        ghost = pygame.Rect(player.x + WIDTH, player.y, PLAYER_W, PLAYER_H)
        pygame.draw.rect(screen, color, ghost)
        pygame.draw.rect(screen, border, ghost, 2)

    # Щит — кружок вокруг персонажа
    if has_shield:
        cx, cy = player.center
        pygame.draw.circle(screen, (100, 200, 255), (cx, cy),
                           PLAYER_W // 2 + 8, 2)


def draw_platform(screen, p):
    color, border = PLATFORM_COLORS[p['type']]
    r = p['rect']

    if p['broken']:
        faded = tuple(min(255, c + 80) for c in color)
        pygame.draw.rect(screen, faded, r)
        pygame.draw.rect(screen, border, r, 1)
        return

    pygame.draw.rect(screen, color, r)
    pygame.draw.rect(screen, border, r, 2)

    if p['type'] == 'spring':
        cx = r.centerx
        cy = r.top - 5
        pygame.draw.circle(screen, (255, 80, 150), (cx, cy), 6)


def draw_enemy(screen, e):
    r = e['rect']
    pygame.draw.circle(screen, (200, 80, 80), r.center, ENEMY_SIZE // 2)
    pygame.draw.circle(screen, (120, 30, 30), r.center, ENEMY_SIZE // 2, 2)
    # Глаза
    pygame.draw.circle(screen, (255, 255, 255),
                       (r.centerx - 5, r.centery - 3), 2)
    pygame.draw.circle(screen, (255, 255, 255),
                       (r.centerx + 5, r.centery - 3), 2)


def draw_bonus(screen, b, fonts):
    r = b['rect']
    color = BONUS_COLORS[b['type']]
    pygame.draw.rect(screen, color, r)
    pygame.draw.rect(screen, (255, 255, 255), r, 2)
    render_text(screen, BONUS_LETTERS[b['type']], fonts['bonus'],
                (0, 0, 0), r.center, center=True)


def draw(screen, fonts):
    screen.fill(BG_COLOR)

    # Платформы
    for p in platforms:
        draw_platform(screen, p)

    # Враги
    for e in enemies:
        draw_enemy(screen, e)

    # Бонусы
    for b in bonuses:
        draw_bonus(screen, b, fonts)

    # Персонаж — только в 'ready' и 'playing'
    if state in ('ready', 'playing'):
        draw_player(screen)

    # HUD
    render_text(screen, f"Счёт: {int(score)}", fonts['hud'], TEXT_DARK, (10, 10))
    render_text(screen, f"Рекорд: {int(highscore)}", fonts['hud_small'],
                TEXT_GRAY, (10, 38))

    if has_shield:
        render_text(screen, "ЩИТ", fonts['hud'], TEXT_SHIELD,
                    (WIDTH - 70, 10))
    if rocket_timer > 0:
        render_text(screen, f"РАКЕТА: {rocket_timer:.1f}", fonts['hud_small'],
                    TEXT_ROCKET, (WIDTH - 150, 38))

    # Подсказка в состоянии 'ready'
    if state == 'ready':
        render_text(screen, "Нажми ПРОБЕЛ, чтобы начать", fonts['large'],
                    TEXT_DARK, (WIDTH // 2, HEIGHT // 2), center=True)
        render_text(screen, "← → или A D — движение", fonts['hint'],
                    TEXT_GRAY, (WIDTH // 2, HEIGHT // 2 + 40), center=True)

    # Экран "Игра окончена"
    if state == 'lost':
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))

        render_text(screen, "ИГРА ОКОНЧЕНА", fonts['title'], TEXT_WHITE,
                    (WIDTH // 2, HEIGHT // 2 - 100), center=True)
        render_text(screen, "Ты поднялся на:", fonts['normal'], TEXT_LIGHT,
                    (WIDTH // 2, HEIGHT // 2 - 30), center=True)
        render_text(screen, f"{int(score)}", fonts['mega'], TEXT_GOLD,
                    (WIDTH // 2, HEIGHT // 2 + 10), center=True)

        if new_record:
            render_text(screen, "НОВЫЙ РЕКОРД!", fonts['large'], TEXT_RECORD,
                        (WIDTH // 2, HEIGHT // 2 + 80), center=True)
        else:
            render_text(screen, f"Рекорд: {int(highscore)}", fonts['normal'],
                        TEXT_LIGHT, (WIDTH // 2, HEIGHT // 2 + 80), center=True)

        render_text(screen, "Нажми R для новой игры", fonts['normal'],
                    TEXT_YELLOW, (WIDTH // 2, HEIGHT // 2 + 150), center=True)


# ==================== ГЛАВНЫЙ ЦИКЛ ====================

async def main():
    global state, vy

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Doodle Jump")
    clock = pygame.time.Clock()

    # Шрифты (встроенный freesansbold поддерживает кириллицу)
    fonts = {
        'hud':       pygame.font.Font(None, 26),
        'hud_small': pygame.font.Font(None, 20),
        'hint':      pygame.font.Font(None, 18),
        'bonus':     pygame.font.Font(None, 20),
        'normal':    pygame.font.Font(None, 22),
        'large':     pygame.font.Font(None, 28),
        'title':     pygame.font.Font(None, 40),
        'mega':      pygame.font.Font(None, 60),
    }

    load_highscore()
    spawn_initial()
    reset_player()

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        # Защита от больших скачков времени (вкладка была в фоне и т.п.)
        if dt > 0.1:
            dt = 0.1

        # ---------- События ----------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                # Пробел — старт
                if state == 'ready' and event.key == pygame.K_SPACE:
                    state = 'playing'
                    vy = -JUMP_POWER
                # R — рестарт после проигрыша
                elif event.key == pygame.K_r and state == 'lost':
                    restart_game()

        # ---------- Логика ----------
        update(dt)

        # ---------- Рисование ----------
        draw(screen, fonts)
        pygame.display.flip()

        # Обязательно для pygbag — отдать управление браузеру
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())