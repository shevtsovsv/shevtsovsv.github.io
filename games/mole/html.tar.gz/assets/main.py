import asyncio
import random
import pygame

# ============================================================
# НАСТРОЙКИ
# ============================================================

WIDTH, HEIGHT = 600, 400
NUM_MOLES = 4
MARGIN = 60
MIN_HIDE_TIME = 1.0
MAX_HIDE_TIME = 2.5
MOLE_SIZE = 60

# ============================================================
# ИНИЦИАЛИЗАЦИЯ
# ============================================================

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Поймай крота")
clock = pygame.time.Clock()

# Картинка крота
mole_img = pygame.image.load("images/mole.png").convert_alpha()
mole_img = pygame.transform.scale(mole_img, (MOLE_SIZE, MOLE_SIZE))

# Шрифты
font_big = pygame.font.SysFont(None, 50)
font_mid = pygame.font.SysFont(None, 30)
font_small = pygame.font.SysFont(None, 25)

# ============================================================
# ИГРОВЫЕ ОБЪЕКТЫ
# ============================================================

def make_mole():
    return {
        "x": random.randint(MARGIN, WIDTH - MARGIN),
        "y": random.randint(MARGIN, HEIGHT - MARGIN),
        "hide_time": random.uniform(MIN_HIDE_TIME, MAX_HIDE_TIME),
    }

def move_mole(m):
    m["x"] = random.randint(MARGIN, WIDTH - MARGIN)
    m["y"] = random.randint(MARGIN, HEIGHT - MARGIN)
    m["hide_time"] = random.uniform(MIN_HIDE_TIME, MAX_HIDE_TIME)

moles = [make_mole() for _ in range(NUM_MOLES)]

score = 0
time_left = 30.0
game_over = False

# ============================================================
# ГЛАВНЫЙ ЦИКЛ
# ============================================================

async def main():
    global score, time_left, game_over

    running = True
    while running:
        dt = clock.tick(60) / 1000.0   # секунды с прошлого кадра

        # --- СОБЫТИЯ ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and not game_over:
                mx, my = event.pos
                for m in moles:
                    rect = pygame.Rect(
                        m["x"] - MOLE_SIZE // 2,
                        m["y"] - MOLE_SIZE // 2,
                        MOLE_SIZE, MOLE_SIZE,
                    )
                    if rect.collidepoint(mx, my):
                        score += 1
                        move_mole(m)
                        break

            elif event.type == pygame.KEYDOWN and game_over:
                if event.key == pygame.K_r:
                    score = 0
                    time_left = 30.0
                    game_over = False
                    for m in moles:
                        move_mole(m)

        # --- ОБНОВЛЕНИЕ ---
        if not game_over:
            time_left -= dt
            if time_left <= 0:
                time_left = 0
                game_over = True

            for m in moles:
                m["hide_time"] -= dt
                if m["hide_time"] <= 0:
                    move_mole(m)

        # --- ОТРИСОВКА ---
        screen.fill((34, 139, 34))

        if game_over:
            text1 = font_big.render("Игра окончена!", True, (255, 255, 255))
            text2 = font_mid.render(f"Твой счёт: {score}", True, (255, 255, 0))
            text3 = font_small.render("Нажми R, чтобы играть снова", True, (255, 255, 255))
            screen.blit(text1, text1.get_rect(center=(WIDTH // 2, 150)))
            screen.blit(text2, text2.get_rect(center=(WIDTH // 2, 220)))
            screen.blit(text3, text3.get_rect(center=(WIDTH // 2, 290)))
        else:
            for m in moles:
                rect = mole_img.get_rect(center=(m["x"], m["y"]))
                screen.blit(mole_img, rect)

            text1 = font_mid.render(f"Счёт: {score}", True, (255, 255, 255))
            text2 = font_mid.render(f"Время: {time_left:.1f}", True, (255, 255, 255))
            screen.blit(text1, (10, 10))
            screen.blit(text2, (WIDTH - 150, 10))

        pygame.display.flip()
        await asyncio.sleep(0)   # <-- отдаём управление браузеру

    pygame.quit()

asyncio.run(main())