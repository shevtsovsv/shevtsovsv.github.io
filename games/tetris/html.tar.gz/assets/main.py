"""
Тетрис на Pygame — версия для pygbag (запуск в браузере).

Как собрать:
    1. Сохраните файл как main.py
    2. Установите pygbag:  pip install pygbag
    3. В папке с файлом запустите:  pygbag .
    4. Откройте http://localhost:8000

На десктопе (Windows/Linux/macOS) запускается как обычно: python main.py
"""
import sys
import asyncio
import random

# --- Заплатка для Windows DPI (только на десктопе; в браузере пропускается) ---
if sys.platform == 'win32':
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
    except Exception:
        pass

import pygame

# --- Константы ---
WIDTH, HEIGHT = 600, 700
COLS, ROWS = 10, 20
CELL = 30
BOARD_X, BOARD_Y = 60, 50
FPS = 60

COLORS = {
    0: (30, 30, 30),
    1: (0, 255, 255),
    2: (255, 255, 0),
    3: (255, 0, 255),
    4: (0, 255, 0),
    5: (255, 0, 0),
    6: (0, 0, 255),
    7: (255, 165, 0),
}
GRID_LINE_COLOR = (60, 60, 60)
BG_COLOR = (10, 10, 30)
PANEL_COLOR = (255, 255, 255)
PANEL_HIGHLIGHT = (255, 255, 0)
OVERLAY_COLOR = (0, 0, 0)
GAME_OVER_COLOR = (255, 0, 0)

# --- Фигуры ---
SHAPES = {
    'I': [(0, 0), (1, 0), (2, 0), (3, 0)],
    'O': [(0, 0), (0, 1), (1, 0), (1, 1)],
    'T': [(0, 1), (1, 0), (1, 1), (1, 2)],
    'S': [(0, 1), (0, 2), (1, 0), (1, 1)],
    'Z': [(0, 0), (0, 1), (1, 1), (1, 2)],
    'J': [(0, 0), (1, 0), (2, 0), (2, 1)],
    'L': [(0, 1), (1, 1), (2, 0), (2, 1)],
}

# --- Состояние игры ---
grid = [[0] * COLS for _ in range(ROWS)]
current = {
    'shape': SHAPES['T'],
    'color': 3,
    'row': 0,
    'col': 3,
}
score = 0
lines_cleared_total = 0
level = 0
game_over = False

fall_interval = 0.5   # секунд между шагами падения
fall_timer = 0.0      # накопитель времени


# ==================== ИГРОВАЯ ЛОГИКА ====================

def reset_game():
    """Полный сброс состояния — для перезапуска по R."""
    global grid, score, lines_cleared_total, level, game_over
    global fall_interval, fall_timer

    grid = [[0] * COLS for _ in range(ROWS)]
    score = 0
    lines_cleared_total = 0
    level = 0
    game_over = False
    fall_interval = 0.5
    fall_timer = 0.0
    spawn_piece()


def rotate_shape(shape):
    """Поворот на 90° по часовой + сдвиг к началу координат."""
    rotated = [(c, -r) for (r, c) in shape]
    min_r = min(r for (r, c) in rotated)
    min_c = min(c for (r, c) in rotated)
    return [(r - min_r, c - min_c) for (r, c) in rotated]


def can_move(dr, dc):
    """Проверка: можно ли сдвинуть текущую фигуру на (dr, dc)."""
    for (sr, sc) in current['shape']:
        new_row = current['row'] + sr + dr
        new_col = current['col'] + sc + dc
        if new_row < 0 or new_row >= ROWS:
            return False
        if new_col < 0 or new_col >= COLS:
            return False
        if grid[new_row][new_col] != 0:
            return False
    return True


def try_rotate():
    """Попытка повернуть фигуру. Если не помещается — откат."""
    old_shape = current['shape']
    current['shape'] = rotate_shape(old_shape)
    if not can_move(0, 0):
        current['shape'] = old_shape


def fix_piece():
    """Зафиксировать фигуру в сетке."""
    for (sr, sc) in current['shape']:
        row = current['row'] + sr
        col = current['col'] + sc
        grid[row][col] = current['color']


def is_row_full(row):
    """Проверка: заполнен ли ряд.

    ВАЖНО: row — это сам список клеток (например [0, 1, 2, 0, ...]),
    а не индекс. Функция вызывается из list comprehension в clear_lines().
    """
    return all(cell != 0 for cell in row)


def clear_lines():
    """Удалить заполненные ряды, начислить очки, обновить уровень."""
    global grid, score, lines_cleared_total, level, fall_interval

    # Собираем список неполных рядов — это устраняет баг со сдвигом индексов
    new_grid = [row for row in grid if not is_row_full(row)]
    cleared = ROWS - len(new_grid)

    if cleared == 0:
        return

    # Добиваем пустыми рядами сверху
    for _ in range(cleared):
        new_grid.insert(0, [0] * COLS)
    grid = new_grid

    # Очки
    if cleared == 1:
        score += 100
    elif cleared == 2:
        score += 300
    elif cleared == 3:
        score += 500
    elif cleared == 4:
        score += 800

    lines_cleared_total += cleared

    # Уровень и ускорение
    new_level = lines_cleared_total // 10
    if new_level != level:
        level = new_level
        fall_interval = max(0.1, 0.5 - level * 0.05)


def spawn_piece():
    """Создать новую случайную фигуру сверху."""
    global game_over
    name = random.choice(list(SHAPES.keys()))
    current['shape'] = SHAPES[name]
    current['color'] = random.randint(1, 7)
    current['row'] = 0
    current['col'] = 3
    if not can_move(0, 0):
        game_over = True


def fall():
    """Один шаг падения фигуры."""
    if game_over:
        return
    if can_move(1, 0):
        current['row'] += 1
    else:
        fix_piece()
        clear_lines()
        spawn_piece()


# ==================== РИСОВАНИЕ ====================

def draw_cell(surface, row, col, color_index):
    x = BOARD_X + col * CELL
    y = BOARD_Y + row * CELL
    pygame.draw.rect(surface, COLORS[color_index], (x, y, CELL, CELL))
    pygame.draw.rect(surface, GRID_LINE_COLOR, (x, y, CELL, CELL), 1)


def render_text(surface, text, font, color, pos, center=False):
    surf = font.render(text, True, color)
    if center:
        rect = surf.get_rect(center=pos)
    else:
        rect = surf.get_rect(topleft=pos)
    surface.blit(surf, rect)


# ==================== ГЛАВНЫЙ ЦИКЛ ====================

async def main():
    global fall_timer

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Тетрис")
    clock = pygame.time.Clock()

    # Шрифты (встроенный freesansbold поддерживает кириллицу)
    font_small = pygame.font.Font(None, 22)
    font_medium = pygame.font.Font(None, 34)
    font_big = pygame.font.Font(None, 50)
    font_hint = pygame.font.Font(None, 26)

    # Авто-повтор стрелок при удержании: задержка 170 мс, шаг 50 мс
    pygame.key.set_repeat(170, 50)

    spawn_piece()

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0

        # ---------- События ----------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if game_over:
                    if event.key == pygame.K_r:
                        reset_game()
                    continue

                if event.key == pygame.K_LEFT and can_move(0, -1):
                    current['col'] -= 1
                elif event.key == pygame.K_RIGHT and can_move(0, 1):
                    current['col'] += 1
                elif event.key == pygame.K_DOWN and can_move(1, 0):
                    current['row'] += 1
                elif event.key == pygame.K_UP:
                    try_rotate()
                elif event.key == pygame.K_SPACE:
                    while can_move(1, 0):
                        current['row'] += 1

        # ---------- Логика ----------
        if not game_over:
            fall_timer += dt
            if fall_timer >= fall_interval:
                fall_timer = 0.0
                fall()

        # ---------- Рисование ----------
        screen.fill(BG_COLOR)

        # Сетка
        for row in range(ROWS):
            for c in range(COLS):
                draw_cell(screen, row, c, grid[row][c])

        # Текущая фигура
        if not game_over:
            for (sr, sc) in current['shape']:
                row = current['row'] + sr
                col = current['col'] + sc
                draw_cell(screen, row, col, current['color'])

        # Панель справа
        panel_x = BOARD_X + COLS * CELL + 20

        render_text(screen, "СЧЁТ", font_small, PANEL_COLOR, (panel_x, 60))
        render_text(screen, str(score), font_medium, PANEL_HIGHLIGHT, (panel_x, 90))

        render_text(screen, "УРОВЕНЬ", font_small, PANEL_COLOR, (panel_x, 160))
        render_text(screen, str(level), font_medium, PANEL_HIGHLIGHT, (panel_x, 190))

        render_text(screen, "ЛИНИИ", font_small, PANEL_COLOR, (panel_x, 260))
        render_text(screen, str(lines_cleared_total), font_medium, PANEL_HIGHLIGHT, (panel_x, 290))

        # Экран "Игра окончена"
        if game_over:
            overlay = pygame.Surface((WIDTH, 200))
            overlay.set_alpha(220)
            overlay.fill(OVERLAY_COLOR)
            screen.blit(overlay, (0, HEIGHT // 2 - 100))

            render_text(screen, "ИГРА ОКОНЧЕНА", font_big, GAME_OVER_COLOR,
                        (WIDTH // 2, HEIGHT // 2 - 40), center=True)
            render_text(screen, f"Твой счёт: {score}", font_medium, PANEL_HIGHLIGHT,
                        (WIDTH // 2, HEIGHT // 2 + 20), center=True)
            render_text(screen, "Нажми R для перезапуска", font_hint, PANEL_COLOR,
                        (WIDTH // 2, HEIGHT // 2 + 70), center=True)

        pygame.display.flip()

        # Обязательно для pygbag — отдать управление браузеру
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())