"""
Top-down RPG на Pygame — версия для pygbag (запуск в браузере).

Как собрать:
    1. Сохраните файл как main.py
    2. Установите pygbag:  pip install pygbag
    3. В папке с файлом запустите:  pygbag .
    4. Откройте http://localhost:8000

На десктопе (Windows/Linux/macOS) запускается как обычно: python main.py
"""
import sys
import asyncio
import random

# --- Заплатка для Windows DPI (только на десктопе; в браузере пропускается) ---
if sys.platform == 'win32':
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
    except Exception:
        pass

import pygame

# ============================================================
# РАЗМЕРЫ
# ============================================================

CELL = 40

WORLD_COLS = 30
WORLD_ROWS = 20

SCREEN_COLS = 16
SCREEN_ROWS = 12

WORLD_W = WORLD_COLS * CELL    # 1200
WORLD_H = WORLD_ROWS * CELL    # 800
WIDTH = SCREEN_COLS * CELL     # 640
HEIGHT = SCREEN_ROWS * CELL    # 480

FPS = 60
MAX_DT = 0.05                  # защита от рывков времени

# ============================================================
# КАРТА
# ============================================================

MAP = [
    "##############################",
    "#............................#",
    "#....######....######....#...#",
    "#....#....#....#....#....#...#",
    "#....#....#....#....#....#...#",
    "#....######....######....#...#",
    "#............................#",
    "#............................#",
    "#~~~~~~~..........~~~~~~~~~~.#",
    "#~~~~~~~..........~~~~~~~~~~.#",
    "#~~~~~~~..........~~~~~~~~~~.#",
    "#~~~~~~~..........~~~~~~~~~~.#",
    "#............................#",
    "#............................#",
    "#....######....######....#...#",
    "#....#....#....#....#....#...#",
    "#....#....#....#....#....#...#",
    "#....######....######....#...#",
    "#............................#",
    "##############################",
]

ROWS = len(MAP)
COLS = len(MAP[0])

SOLID = {'#', 'T', '~', 'R'}

# ============================================================
# ПЕРСОНАЖ
# ============================================================

PLAYER_SIZE = 30
PLAYER_SPEED = 3

player = pygame.Rect(
    WORLD_W // 2 - PLAYER_SIZE // 2,
    WORLD_H // 2 - PLAYER_SIZE // 2,
    PLAYER_SIZE, PLAYER_SIZE
)

direction = 'down'

# ============================================================
# NPC
# ============================================================

NPC_SIZE = 30
NPC_INTERACT_DIST = 60

npcs = [
    {
        'rect': pygame.Rect(125, 245, NPC_SIZE, NPC_SIZE),
        'name': 'Старик',
        'color': (200, 170, 100),
        'dialogues': [
            'Здравствуй, путник!',
            'Добро пожаловать в нашу деревню.',
            'Будь осторожен — за рекой водятся монстры.',
            'Если найдёшь меч, сможешь с ними справиться.',
        ],
    },
    {
        'rect': pygame.Rect(1005, 285, NPC_SIZE, NPC_SIZE),
        'name': 'Девушка',
        'color': (220, 150, 200),
        'dialogues': [
            'Привет! Ты новый здесь?',
            'Я собираю цветы у реки.',
            'Только не подходи к воде — там глубоко.',
        ],
    },
    {
        'rect': pygame.Rect(605, 525, NPC_SIZE, NPC_SIZE),
        'name': 'Стражник',
        'color': (200, 90, 90),
        'dialogues': [
            'Стой! Кто идёт?',
            '...А, свои. Проходи.',
            'Если увидишь монстров — зови меня.',
        ],
    },
]

# ============================================================
# ПРЕДМЕТЫ
# ============================================================

ITEM_SIZE = 24
POTION_HEAL = 30
COIN_VALUE = 10


def create_items():
    return [
        {'rect': pygame.Rect(100, 60, ITEM_SIZE, ITEM_SIZE),  'type': 'coin',   'color': (255, 215, 0)},
        {'rect': pygame.Rect(200, 60, ITEM_SIZE, ITEM_SIZE),  'type': 'coin',   'color': (255, 215, 0)},
        {'rect': pygame.Rect(300, 60, ITEM_SIZE, ITEM_SIZE),  'type': 'coin',   'color': (255, 215, 0)},
        {'rect': pygame.Rect(500, 300, ITEM_SIZE, ITEM_SIZE), 'type': 'potion', 'color': (200, 50, 200)},
        {'rect': pygame.Rect(700, 300, ITEM_SIZE, ITEM_SIZE), 'type': 'key',    'color': (220, 220, 120)},
        {'rect': pygame.Rect(400, 500, ITEM_SIZE, ITEM_SIZE), 'type': 'coin',   'color': (255, 215, 0)},
        {'rect': pygame.Rect(800, 500, ITEM_SIZE, ITEM_SIZE), 'type': 'potion', 'color': (200, 50, 200)},
        {'rect': pygame.Rect(200, 740, ITEM_SIZE, ITEM_SIZE), 'type': 'coin',   'color': (255, 215, 0)},
        {'rect': pygame.Rect(600, 740, ITEM_SIZE, ITEM_SIZE), 'type': 'key',    'color': (220, 220, 120)},
        {'rect': pygame.Rect(900, 740, ITEM_SIZE, ITEM_SIZE), 'type': 'coin',   'color': (255, 215, 0)},
    ]


items = create_items()

# ============================================================
# ИНВЕНТАРЬ И ЗДОРОВЬЕ
# ============================================================

inventory = {'potion': 0, 'key': 0}
gold = 0

hp = 100
max_hp = 100

last_message = ""
message_timer = 0.0

kills = 0
coins_collected = 0

# ============================================================
# КВЕСТЫ
# ============================================================

quests = {
    'kill_3': {
        'name': 'Истребитель',
        'description': 'Убей 3 врагов',
        'goal': 3,
        'progress': 0,
        'state': 'active',
        'reward_gold': 50,
    },
    'collect_5': {
        'name': 'Коллекционер',
        'description': 'Собери 5 монет',
        'goal': 5,
        'progress': 0,
        'state': 'active',
        'reward_gold': 30,
    },
    'find_key': {
        'name': 'Ключник',
        'description': 'Найди ключ',
        'goal': 1,
        'progress': 0,
        'state': 'active',
        'reward_gold': 100,
    },
}

# ============================================================
# ВРАГИ
# ============================================================

ENEMY_SIZE = 28
ENEMY_DAMAGE = 10
ENEMY_ATTACK_COOLDOWN = 1.0
ENEMY_CHASE_DIST = 180
ENEMY_ATTACK_DIST = 35


def create_enemies():
    return [
        {
            'rect': pygame.Rect(300, 300, ENEMY_SIZE, ENEMY_SIZE),
            'hp': 30, 'max_hp': 30,
            'color': (180, 60, 180),
            'speed': 1.2,
            'dir_x': 1, 'dir_y': 0,
            'turn_timer': 0,
            'attack_timer': 0,
            'hit_timer': 0,
        },
        {
            'rect': pygame.Rect(900, 300, ENEMY_SIZE, ENEMY_SIZE),
            'hp': 30, 'max_hp': 30,
            'color': (180, 60, 180),
            'speed': 1.2,
            'dir_x': -1, 'dir_y': 0,
            'turn_timer': 0,
            'attack_timer': 0,
            'hit_timer': 0,
        },
        {
            'rect': pygame.Rect(600, 700, ENEMY_SIZE, ENEMY_SIZE),
            'hp': 30, 'max_hp': 30,
            'color': (180, 60, 180),
            'speed': 1.2,
            'dir_x': 0, 'dir_y': -1,
            'turn_timer': 0,
            'attack_timer': 0,
            'hit_timer': 0,
        },
    ]


enemies = create_enemies()

# ============================================================
# БОЙ
# ============================================================

PLAYER_ATTACK_DAMAGE = 10
PLAYER_ATTACK_COOLDOWN = 0.4
PLAYER_ATTACK_DURATION = 0.15
PLAYER_ATTACK_RANGE = 45
REWARD_ENEMY = 15

# ============================================================
# СОСТОЯНИЕ ИГРЫ
# ============================================================

state = 'playing'
attack_timer = 0.0
attack_cooldown = 0.0

show_journal = False

# ============================================================
# КАМЕРА И АНИМАЦИЯ
# ============================================================

cam_x = 0
cam_y = 0

walk_timer = 0.0
bob_offset = 0

# ============================================================
# ДИАЛОГ
# ============================================================

in_dialogue = False
current_npc = None
dialogue_index = 0


# ============================================================
# ФУНКЦИИ
# ============================================================

def tile_at(x, y):
    col = int(x // CELL)
    row = int(y // CELL)
    if row < 0 or row >= ROWS or col < 0 or col >= COLS:
        return '#'
    return MAP[row][col]


def can_move_to(x, y):
    corners = [
        (x, y),
        (x + PLAYER_SIZE - 1, y),
        (x, y + PLAYER_SIZE - 1),
        (x + PLAYER_SIZE - 1, y + PLAYER_SIZE - 1),
    ]
    for (cx, cy) in corners:
        if tile_at(cx, cy) in SOLID:
            return False
    return True


def can_enemy_move_to(x, y):
    corners = [
        (x, y),
        (x + ENEMY_SIZE - 1, y),
        (x, y + ENEMY_SIZE - 1),
        (x + ENEMY_SIZE - 1, y + ENEMY_SIZE - 1),
    ]
    for (cx, cy) in corners:
        if tile_at(cx, cy) in SOLID:
            return False
    return True


def try_move_enemy(e, mx, my):
    nx = e['rect'].x + mx
    ny = e['rect'].y + my
    if can_enemy_move_to(nx, e['rect'].y):
        e['rect'].x = nx
    if can_enemy_move_to(e['rect'].x, ny):
        e['rect'].y = ny


def update_camera():
    global cam_x, cam_y
    cam_x = player.centerx - WIDTH // 2
    cam_y = player.centery - HEIGHT // 2

    if cam_x < 0:
        cam_x = 0
    if cam_y < 0:
        cam_y = 0
    if cam_x > WORLD_W - WIDTH:
        cam_x = WORLD_W - WIDTH
    if cam_y > WORLD_H - HEIGHT:
        cam_y = WORLD_H - HEIGHT


def world_to_screen(x, y):
    return (x - cam_x, y - cam_y)


def find_nearest_npc():
    for npc in npcs:
        dx = player.centerx - npc['rect'].centerx
        dy = player.centery - npc['rect'].centery
        dist = (dx * dx + dy * dy) ** 0.5
        if dist < NPC_INTERACT_DIST:
            return npc
    return None


def set_message(text):
    global last_message, message_timer
    last_message = text
    message_timer = 2.0


def advance_quest(quest_id, amount=1):
    """Увеличивает прогресс квеста и начисляет награду при завершении."""
    global gold

    q = quests.get(quest_id)
    if q is None:
        return
    if q['state'] != 'active':
        return

    q['progress'] += amount
    if q['progress'] >= q['goal']:
        q['progress'] = q['goal']
        q['state'] = 'done'
        gold += q['reward_gold']
        set_message(f"Квест выполнен: {q['name']}! +{q['reward_gold']} золота")


def pickup_items():
    global gold, coins_collected

    for i in range(len(items) - 1, -1, -1):
        item = items[i]
        if player.colliderect(item['rect']):

            if item['type'] == 'coin':
                gold += COIN_VALUE
                coins_collected += 1
                set_message(f"+{COIN_VALUE} золота")
                advance_quest('collect_5', 1)

            elif item['type'] == 'potion':
                inventory['potion'] += 1
                set_message("Подобрано зелье")

            elif item['type'] == 'key':
                inventory['key'] += 1
                set_message("Подобран ключ")
                advance_quest('find_key', 1)

            items.pop(i)


def use_potion():
    global hp
    if inventory['potion'] <= 0:
        set_message("Нет зелий")
        return
    if hp >= max_hp:
        set_message("Здоровье полное")
        return
    inventory['potion'] -= 1
    hp = min(max_hp, hp + POTION_HEAL)
    set_message(f"+{POTION_HEAL} HP")


def get_attack_hitbox():
    if direction == 'right':
        return pygame.Rect(player.right, player.y, PLAYER_ATTACK_RANGE, PLAYER_SIZE)
    elif direction == 'left':
        return pygame.Rect(player.left - PLAYER_ATTACK_RANGE, player.y,
                           PLAYER_ATTACK_RANGE, PLAYER_SIZE)
    elif direction == 'up':
        return pygame.Rect(player.x, player.top - PLAYER_ATTACK_RANGE,
                           PLAYER_SIZE, PLAYER_ATTACK_RANGE)
    else:
        return pygame.Rect(player.x, player.bottom, PLAYER_SIZE, PLAYER_ATTACK_RANGE)


def player_attack():
    global attack_timer, attack_cooldown, gold, kills
    if attack_cooldown > 0:
        return
    attack_cooldown = PLAYER_ATTACK_COOLDOWN
    attack_timer = PLAYER_ATTACK_DURATION
    hitbox = get_attack_hitbox()
    for i in range(len(enemies) - 1, -1, -1):
        e = enemies[i]
        if hitbox.colliderect(e['rect']):
            e['hp'] -= PLAYER_ATTACK_DAMAGE
            e['hit_timer'] = 0.2
            if e['hp'] <= 0:
                enemies.pop(i)
                gold += REWARD_ENEMY
                kills += 1
                set_message(f"Враг побеждён! +{REWARD_ENEMY} золота")
                advance_quest('kill_3', 1)


def update_enemies(dt):
    global hp, state
    factor = dt * 60    # масштабирование под 60 FPS
    for e in enemies:
        if e['hit_timer'] > 0:
            e['hit_timer'] -= dt
            if e['hit_timer'] < 0:
                e['hit_timer'] = 0

        dx = player.centerx - e['rect'].centerx
        dy = player.centery - e['rect'].centery
        dist = (dx * dx + dy * dy) ** 0.5

        if dist < ENEMY_CHASE_DIST:
            if dist > 1:
                mx = (dx / dist) * e['speed'] * factor
                my = (dy / dist) * e['speed'] * factor
                try_move_enemy(e, mx, my)
        else:
            e['turn_timer'] -= dt
            if e['turn_timer'] <= 0:
                e['dir_x'] = random.choice([-1, 0, 1])
                e['dir_y'] = random.choice([-1, 0, 1])
                e['turn_timer'] = random.uniform(1.0, 2.0)
            try_move_enemy(e,
                           e['dir_x'] * e['speed'] * factor,
                           e['dir_y'] * e['speed'] * factor)

        e['attack_timer'] -= dt
        if dist < ENEMY_ATTACK_DIST and e['attack_timer'] <= 0:
            hp -= ENEMY_DAMAGE
            e['attack_timer'] = ENEMY_ATTACK_COOLDOWN
            set_message(f"Получено {ENEMY_DAMAGE} урона!")
            if hp <= 0:
                hp = 0
                state = 'lost'


# ============================================================
# СОХРАНЕНИЕ / ЗАГРУЗКА
# Внимание: в pygbag ФС виртуальная — файл живёт до перезагрузки страницы.
# ============================================================

def save_game():
    try:
        with open("savegame.txt", "w") as f:
            f.write(f"{player.x},{player.y}\n")
            f.write(f"{hp},{gold}\n")
            f.write(f"{inventory['potion']},{inventory['key']}\n")
            f.write(f"{kills},{coins_collected}\n")
            f.write(f"{quests['kill_3']['progress']},"
                    f"{quests['collect_5']['progress']},"
                    f"{quests['find_key']['progress']}\n")
        set_message("Игра сохранена")
    except Exception:
        set_message("Ошибка сохранения")


def load_game():
    """Загружает игру из savegame.txt. Возвращает True при успехе."""
    global hp, gold, kills, coins_collected
    try:
        with open("savegame.txt", "r") as f:
            lines = f.read().strip().split("\n")

            px, py = lines[0].split(",")
            player.x = float(px)
            player.y = float(py)

            hp_s, gold_s = lines[1].split(",")
            hp = int(hp_s)
            gold = int(gold_s)

            pot, key = lines[2].split(",")
            inventory['potion'] = int(pot)
            inventory['key'] = int(key)

            k, c = lines[3].split(",")
            kills = int(k)
            coins_collected = int(c)

            q1, q2, q3 = lines[4].split(",")
            quests['kill_3']['progress'] = int(q1)
            quests['collect_5']['progress'] = int(q2)
            quests['find_key']['progress'] = int(q3)

            for q in quests.values():
                if q['progress'] >= q['goal']:
                    q['state'] = 'done'

        return True
    except Exception:
        return False


def restart_game():
    global state, hp, gold, inventory
    global attack_timer, attack_cooldown, message_timer
    global cam_x, cam_y
    global kills, coins_collected, show_journal

    state = 'playing'
    hp = max_hp
    gold = 0
    inventory = {'potion': 0, 'key': 0}
    kills = 0
    coins_collected = 0

    attack_timer = 0
    attack_cooldown = 0
    message_timer = 0
    show_journal = False

    player.x = WORLD_W // 2 - PLAYER_SIZE // 2
    player.y = WORLD_H // 2 - PLAYER_SIZE // 2

    for q in quests.values():
        q['progress'] = 0
        q['state'] = 'active'

    enemies[:] = create_enemies()
    items[:] = create_items()

    cam_x = 0
    cam_y = 0


# ============================================================
# ОБНОВЛЕНИЕ
# ============================================================

def update(dt):
    global direction, walk_timer, bob_offset, message_timer
    global attack_timer, attack_cooldown

    if state != 'playing':
        return

    if in_dialogue:
        return

    if show_journal:
        return

    # Таймеры по dt
    if message_timer > 0:
        message_timer -= dt
        if message_timer < 0:
            message_timer = 0

    if attack_timer > 0:
        attack_timer -= dt
        if attack_timer < 0:
            attack_timer = 0
    if attack_cooldown > 0:
        attack_cooldown -= dt
        if attack_cooldown < 0:
            attack_cooldown = 0

    # Горизонталь
    dx = 0
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] or keys[pygame.K_a]:
        dx = -PLAYER_SPEED
        direction = 'left'
    elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
        dx = PLAYER_SPEED
        direction = 'right'

    if dx != 0:
        if can_move_to(player.x + dx, player.y):
            player.x += dx

    # Вертикаль
    dy = 0
    if keys[pygame.K_UP] or keys[pygame.K_w]:
        dy = -PLAYER_SPEED
        direction = 'up'
    elif keys[pygame.K_DOWN] or keys[pygame.K_s]:
        dy = PLAYER_SPEED
        direction = 'down'

    if dy != 0:
        if can_move_to(player.x, player.y + dy):
            player.y += dy

    # Анимация ходьбы
    moving = (dx != 0 or dy != 0)
    if moving:
        walk_timer += dt
        if walk_timer > 0.2:
            walk_timer = 0
        if walk_timer < 0.1:
            bob_offset = -2
        else:
            bob_offset = 2
    else:
        bob_offset = 0
        walk_timer = 0

    pickup_items()
    update_enemies(dt)
    update_camera()


# ============================================================
# РИСОВАНИЕ
# ============================================================

def render_text(surface, text, font, color, pos, center=False):
    surf = font.render(text, True, color)
    if center:
        rect = surf.get_rect(center=pos)
    else:
        rect = surf.get_rect(topleft=pos)
    surface.blit(surf, rect)


def draw_player(screen):
    px = player.x - cam_x
    py = player.y - cam_y + bob_offset

    rect = pygame.Rect(px, py, PLAYER_SIZE, PLAYER_SIZE)
    pygame.draw.rect(screen, (60, 100, 200), rect)
    pygame.draw.rect(screen, (30, 50, 120), rect, 2)

    cx = int(px + PLAYER_SIZE // 2)
    cy = int(py + PLAYER_SIZE // 2)

    eye_color = (255, 255, 255)
    pupil_color = (20, 20, 20)

    if direction == 'up':
        pygame.draw.circle(screen, eye_color, (cx - 6, cy - 4), 3)
        pygame.draw.circle(screen, eye_color, (cx + 6, cy - 4), 3)
        pygame.draw.circle(screen, pupil_color, (cx - 6, cy - 5), 1)
        pygame.draw.circle(screen, pupil_color, (cx + 6, cy - 5), 1)
    elif direction == 'down':
        pygame.draw.circle(screen, eye_color, (cx - 6, cy + 4), 3)
        pygame.draw.circle(screen, eye_color, (cx + 6, cy + 4), 3)
        pygame.draw.circle(screen, pupil_color, (cx - 6, cy + 5), 1)
        pygame.draw.circle(screen, pupil_color, (cx + 6, cy + 5), 1)
    elif direction == 'left':
        pygame.draw.circle(screen, eye_color, (cx - 8, cy - 2), 3)
        pygame.draw.circle(screen, eye_color, (cx - 2, cy - 2), 3)
        pygame.draw.circle(screen, pupil_color, (cx - 9, cy - 2), 1)
        pygame.draw.circle(screen, pupil_color, (cx - 3, cy - 2), 1)
    elif direction == 'right':
        pygame.draw.circle(screen, eye_color, (cx + 2, cy - 2), 3)
        pygame.draw.circle(screen, eye_color, (cx + 8, cy - 2), 3)
        pygame.draw.circle(screen, pupil_color, (cx + 3, cy - 2), 1)
        pygame.draw.circle(screen, pupil_color, (cx + 9, cy - 2), 1)


def draw_npc(screen, npc):
    r = npc['rect']
    sx = int(r.x - cam_x)
    sy = int(r.y - cam_y)

    rect = pygame.Rect(sx, sy, NPC_SIZE, NPC_SIZE)
    pygame.draw.rect(screen, npc['color'], rect)
    pygame.draw.rect(screen, (40, 30, 20), rect, 2)

    cx = sx + NPC_SIZE // 2
    cy = sy + NPC_SIZE // 2

    dx = player.centerx - r.centerx
    dy = player.centery - r.centery
    max_d = max(abs(dx), abs(dy), 1)
    ox = int((dx / max_d) * 2)
    oy = int((dy / max_d) * 2)

    pygame.draw.circle(screen, (255, 255, 255), (cx - 5, cy), 3)
    pygame.draw.circle(screen, (255, 255, 255), (cx + 5, cy), 3)
    pygame.draw.circle(screen, (20, 20, 20), (cx - 5 + ox, cy + oy), 2)
    pygame.draw.circle(screen, (20, 20, 20), (cx + 5 + ox, cy + oy), 2)


def draw_enemy(screen, e):
    r = e['rect']
    sx = int(r.x - cam_x)
    sy = int(r.y - cam_y)

    if e['hit_timer'] > 0:
        color = (255, 255, 255)
    else:
        color = e['color']

    rect = pygame.Rect(sx, sy, ENEMY_SIZE, ENEMY_SIZE)
    pygame.draw.rect(screen, color, rect)
    pygame.draw.rect(screen, (60, 20, 60), rect, 2)

    cx = sx + ENEMY_SIZE // 2
    cy = sy + ENEMY_SIZE // 2
    dx = player.centerx - r.centerx
    dy = player.centery - r.centery
    max_d = max(abs(dx), abs(dy), 1)
    ox = int((dx / max_d) * 2)
    oy = int((dy / max_d) * 2)

    pygame.draw.circle(screen, (255, 255, 255), (cx - 5, cy), 3)
    pygame.draw.circle(screen, (255, 255, 255), (cx + 5, cy), 3)
    pygame.draw.circle(screen, (20, 20, 20), (cx - 5 + ox, cy + oy), 2)
    pygame.draw.circle(screen, (20, 20, 20), (cx + 5 + ox, cy + oy), 2)

    bar_w = ENEMY_SIZE
    bar_h = 4
    bar_x = sx
    bar_y = sy - 8
    pygame.draw.rect(screen, (60, 20, 20), (bar_x, bar_y, bar_w, bar_h))
    ratio = e['hp'] / e['max_hp']
    if ratio < 0:
        ratio = 0
    if ratio > 0:
        pygame.draw.rect(screen, (220, 60, 60),
                         (bar_x, bar_y, int(bar_w * ratio), bar_h))


def draw_items(screen):
    for item in items:
        r = item['rect']
        sx = int(r.x - cam_x)
        sy = int(r.y - cam_y)

        rect = pygame.Rect(sx, sy, ITEM_SIZE, ITEM_SIZE)
        pygame.draw.rect(screen, item['color'], rect)
        pygame.draw.rect(screen, (255, 255, 255), rect, 2)

        if item['type'] == 'coin':
            pygame.draw.circle(screen, (150, 120, 0),
                               (sx + ITEM_SIZE // 2, sy + ITEM_SIZE // 2),
                               ITEM_SIZE // 2 - 2, 2)


def draw_attack(screen):
    if attack_timer <= 0:
        return
    hb = get_attack_hitbox()
    sx = int(hb.x - cam_x)
    sy = int(hb.y - cam_y)
    rect = pygame.Rect(sx, sy, hb.width, hb.height)
    pygame.draw.rect(screen, (255, 240, 120), rect)
    pygame.draw.rect(screen, (200, 180, 0), rect, 2)


def draw_interact_hint(screen, npc, fonts):
    r = npc['rect']
    sx = int(r.x - cam_x + NPC_SIZE // 2)
    sy = int(r.y - cam_y - 25)

    pygame.draw.circle(screen, (255, 255, 100), (sx, sy), 14)
    pygame.draw.circle(screen, (150, 150, 0), (sx, sy), 14, 2)
    render_text(screen, "E", fonts['hint'], (0, 0, 0), (sx, sy - 2), center=True)


def draw_hud(screen, fonts):
    render_text(screen, f"Золото: {gold}", fonts['medium'],
                (255, 215, 0), (10, 8))

    bar_x = 10
    bar_y = 38
    bar_w = 200
    bar_h = 20

    pygame.draw.rect(screen, (60, 20, 20), (bar_x, bar_y, bar_w, bar_h))
    ratio = hp / max_hp
    if ratio > 0:
        pygame.draw.rect(screen, (220, 60, 60),
                         (bar_x, bar_y, int(bar_w * ratio), bar_h))
    pygame.draw.rect(screen, (255, 255, 255),
                     (bar_x, bar_y, bar_w, bar_h), 2)
    render_text(screen, f"{hp}/{max_hp}", fonts['tiny'], (255, 255, 255),
                (bar_x + bar_w // 2, bar_y + bar_h // 2), center=True)

    render_text(screen, f"[1] Зелья: {inventory['potion']}",
                fonts['normal'], (220, 120, 220), (10, 68))
    render_text(screen, f"    Ключи: {inventory['key']}",
                fonts['normal'], (220, 220, 120), (10, 90))


def draw_mini_quests(screen, fonts):
    x = WIDTH - 180
    y = 10
    for q in quests.values():
        if q['state'] == 'done':
            color = (100, 255, 100)
            text = f"OK {q['name']}"
        else:
            color = (255, 220, 100)
            text = f"{q['name']}: {q['progress']}/{q['goal']}"
        render_text(screen, text, fonts['small'], color, (x, y))
        y += 20


def draw_message(screen, fonts):
    if message_timer > 0:
        text_w = 380
        bg = pygame.Rect(WIDTH // 2 - text_w // 2, 8, text_w, 32)
        pygame.draw.rect(screen, (30, 30, 60), bg)
        pygame.draw.rect(screen, (200, 200, 100), bg, 2)
        render_text(screen, last_message, fonts['normal'], (255, 255, 0),
                    (WIDTH // 2, 24), center=True)


def draw_dialogue(screen, fonts):
    if not in_dialogue or current_npc is None:
        return

    box_h = 130
    box_y = HEIGHT - box_h

    pygame.draw.rect(screen, (20, 20, 40), (0, box_y, WIDTH, box_h))
    pygame.draw.rect(screen, (200, 200, 200), (0, box_y, WIDTH, box_h), 2)

    render_text(screen, current_npc['name'], fonts['large'],
                (255, 220, 100), (20, box_y + 12))

    text = current_npc['dialogues'][dialogue_index]
    render_text(screen, text, fonts['medium'], (255, 255, 255),
                (20, box_y + 55))

    render_text(screen, "ПРОБЕЛ — далее", fonts['small'],
                (180, 180, 180), (WIDTH // 2, HEIGHT - 15), center=True)


def draw_journal(screen, fonts):
    if not show_journal:
        return

    overlay = pygame.Surface((WIDTH, HEIGHT))
    overlay.fill((0, 0, 0))
    screen.blit(overlay, (0, 0))

    render_text(screen, "ЖУРНАЛ КВЕСТОВ", fonts['big'], (255, 215, 0),
                (WIDTH // 2, 40), center=True)

    y = 100
    for q in quests.values():
        if q['state'] == 'done':
            color = (100, 255, 100)
            status = "[ВЫПОЛНЕН]"
        else:
            color = (255, 220, 100)
            status = f"[{q['progress']}/{q['goal']}]"

        render_text(screen, f"{q['name']}  {status}", fonts['large'],
                    color, (40, y))
        render_text(screen, q['description'], fonts['medium'],
                    (180, 180, 180), (40, y + 28))
        render_text(screen, f"Награда: {q['reward_gold']} золота",
                    fonts['normal'], (200, 200, 100), (40, y + 50))
        y += 90

    render_text(screen, "Q — закрыть журнал", fonts['medium'],
                (200, 200, 200), (WIDTH // 2, HEIGHT - 30), center=True)


def draw(screen, fonts):
    screen.fill((0, 0, 0))

    # Карта
    start_col = int(cam_x // CELL)
    start_row = int(cam_y // CELL)
    for row in range(start_row, start_row + SCREEN_ROWS + 2):
        for col in range(start_col, start_col + SCREEN_COLS + 2):
            if row < 0 or row >= ROWS or col < 0 or col >= COLS:
                continue
            wx = col * CELL
            wy = row * CELL
            sx, sy = world_to_screen(wx, wy)
            symbol = MAP[row][col]

            if symbol == '#':
                color = (80, 60, 40)
            elif symbol == '~':
                color = (60, 100, 200)
            elif symbol == 'T':
                color = (40, 90, 40)
            else:
                color = (100, 180, 100)

            pygame.draw.rect(screen, color,
                             (int(sx), int(sy), CELL, CELL))

    # Предметы
    draw_items(screen)

    # NPC
    for npc in npcs:
        draw_npc(screen, npc)

    # Враги
    for e in enemies:
        draw_enemy(screen, e)

    # Персонаж
    draw_player(screen)

    # Взмах меча
    draw_attack(screen)

    # Подсказка E
    if not in_dialogue and state == 'playing' and not show_journal:
        npc = find_nearest_npc()
        if npc:
            draw_interact_hint(screen, npc, fonts)

    # Подсказка управления
    if not in_dialogue and state == 'playing' and not show_journal:
        render_text(screen,
                    "WASD — движение, E — говорить, Space — удар",
                    fonts['tiny'], (255, 255, 255),
                    (WIDTH // 2, HEIGHT - 28), center=True)
        render_text(screen,
                    "1 — зелье, Q — журнал, S — сохранить, L — загрузить",
                    fonts['tiny'], (200, 200, 200),
                    (WIDTH // 2, HEIGHT - 10), center=True)

    # HUD
    draw_hud(screen, fonts)
    draw_mini_quests(screen, fonts)
    draw_message(screen, fonts)

    # Диалог
    draw_dialogue(screen, fonts)

    # Экран проигрыша
    if state == 'lost':
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))

        render_text(screen, "ИГРА ОКОНЧЕНА", fonts['big'], (255, 0, 0),
                    (WIDTH // 2, HEIGHT // 2 - 60), center=True)
        render_text(screen, f"Золото: {gold}", fonts['large'], (255, 215, 0),
                    (WIDTH // 2, HEIGHT // 2), center=True)
        render_text(screen, "Нажми R для новой игры", fonts['medium'],
                    (255, 255, 255),
                    (WIDTH // 2, HEIGHT // 2 + 70), center=True)

    # Журнал — поверх всего
    draw_journal(screen, fonts)


# ============================================================
# ОБРАБОТКА КЛАВИШ
# ============================================================

def handle_keydown(key):
    global in_dialogue, current_npc, dialogue_index, show_journal

    # Перезапуск
    if state == 'lost':
        if key == pygame.K_r:
            restart_game()
        return

    # Журнал квестов — открыть/закрыть
    if key == pygame.K_q:
        show_journal = not show_journal
        return

    # Если журнал открыт — только Q закрывает
    if show_journal:
        return

    # Сохранить
    if key == pygame.K_s:
        save_game()
        return

    # Загрузить
    if key == pygame.K_l:
        if load_game():
            set_message("Игра загружена")
        else:
            set_message("Нет сохранения")
        return

    # Диалог — далее
    if in_dialogue:
        if key == pygame.K_SPACE or key == pygame.K_e:
            dialogue_index += 1
            if dialogue_index >= len(current_npc['dialogues']):
                in_dialogue = False
                current_npc = None
                dialogue_index = 0
        return

    # Зелье
    if key == pygame.K_1:
        use_potion()
        return

    # Атака
    if key == pygame.K_SPACE:
        player_attack()
        return

    # Разговор
    if key == pygame.K_e:
        npc = find_nearest_npc()
        if npc:
            in_dialogue = True
            current_npc = npc
            dialogue_index = 0


# ============================================================
# ГЛАВНЫЙ ЦИКЛ
# ============================================================

async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Top-down RPG")
    clock = pygame.time.Clock()

    # Шрифты (встроенный freesansbold поддерживает кириллицу)
    fonts = {
        'tiny':   pygame.font.Font(None, 13),
        'small':  pygame.font.Font(None, 15),
        'normal': pygame.font.Font(None, 17),
        'medium': pygame.font.Font(None, 21),
        'large':  pygame.font.Font(None, 23),
        'big':    pygame.font.Font(None, 34),
        'hint':   pygame.font.Font(None, 20),
    }

    update_camera()

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        if dt > MAX_DT:
            dt = MAX_DT

        # ---------- События ----------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                handle_keydown(event.key)

        # ---------- Логика ----------
        update(dt)

        # ---------- Рисование ----------
        draw(screen, fonts)
        pygame.display.flip()

        # Обязательно для pygbag — отдать управление браузеру
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())