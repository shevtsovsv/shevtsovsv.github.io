"""
Tower Defense на Pygame — версия для pygbag (запуск в браузере).

Как собрать:
    1. Сохраните файл как main.py
    2. Установите pygbag:  pip install pygbag
    3. В папке с файлом запустите:  pygbag .
    4. Откройте http://localhost:8000

На десктопе (Windows/Linux/macOS) запускается как обычно: python main.py
"""
import sys
import asyncio
import math

# --- Заплатка для Windows DPI (только на десктопе; в браузере пропускается) ---
if sys.platform == 'win32':
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass
    except Exception:
        pass

import pygame

# ==================== КОНСТАНТЫ ====================
WIDTH = 600
HEIGHT = 600
FPS = 60

# --- Сетка ---
CELL = 40
GRID_COLS = WIDTH // CELL
GRID_ROWS = HEIGHT // CELL

# --- Деньги ---
START_MONEY = 200
TOWER_COST = 50

# --- Стрельба ---
TOWER_RANGE = 120
TOWER_COOLDOWN = 45           # в "кадрах при 60 FPS" (~0.75 сек)
TOWER_DAMAGE = 1
PROJECTILE_SPEED = 8          # пикселей за кадр при 60 FPS
PROJECTILE_RADIUS = 5

# --- Игра ---
START_LIVES = 10
REWARD_KILL = 20
PAUSE_BETWEEN_WAVES = 3.0     # секунд

# --- Уровни ---
LEVELS = [
    {
        'path': [
            (-30, 150), (200, 150), (200, 400),
            (400, 400), (400, 200), (630, 200),
        ],
        'waves': [
            {'count': 5, 'delay': 2.0, 'hp': 3, 'speed': 1.5},
            {'count': 7, 'delay': 1.7, 'hp': 4, 'speed': 1.6},
        ],
        'bg_color': (20, 20, 30),
    },
    {
        'path': [
            (-30, 100), (100, 100), (100, 500),
            (500, 500), (500, 300), (630, 300),
        ],
        'waves': [
            {'count': 6, 'delay': 1.8, 'hp': 4, 'speed': 1.7},
            {'count': 10, 'delay': 1.3, 'hp': 5, 'speed': 1.9},
        ],
        'bg_color': (25, 18, 40),
    },
    {
        'path': [
            (-30, 500), (150, 500), (150, 100),
            (450, 100), (450, 400), (630, 400),
        ],
        'waves': [
            {'count': 8, 'delay': 1.5, 'hp': 5, 'speed': 2.0},
            {'count': 12, 'delay': 1.0, 'hp': 7, 'speed': 2.2},
        ],
        'bg_color': (30, 20, 25),
    },
]

# ==================== СОСТОЯНИЕ ====================
state = 'playing'          # 'playing', 'won', 'lost'
lives = START_LIVES
money = START_MONEY
kills = 0

current_level = 0
current_wave = 0
enemies_spawned = 0
spawn_timer = 0.0
between_waves = False
pause_timer = 0.0
between_levels = False
level_pause_timer = 0.0

enemies = []
towers = []
bullets = []


# ==================== ХЕЛПЕРЫ ====================

def current_path():
    return LEVELS[current_level]['path']


def current_waves():
    return LEVELS[current_level]['waves']


def current_bg():
    return LEVELS[current_level]['bg_color']


def distance(x1, y1, x2, y2):
    return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)


# ==================== ВРАГИ ====================

def make_enemy(wave):
    path = current_path()
    return {
        'x': path[0][0],
        'y': path[0][1],
        'target_index': 1,
        'speed': wave['speed'],
        'hp': wave['hp'],
        'max_hp': wave['hp'],
        'color': (220, 120, 120),
        'size': 20,
    }


def update_enemy(e, frame_factor):
    """Двигаем врага к следующей точке. False — если дошёл до конца пути."""
    path = current_path()
    if e['target_index'] >= len(path):
        return False
    tx, ty = path[e['target_index']]
    dx = tx - e['x']
    dy = ty - e['y']
    dist = math.sqrt(dx * dx + dy * dy)
    step = e['speed'] * frame_factor
    if dist < step:
        e['target_index'] += 1
    else:
        e['x'] += dx / dist * step
        e['y'] += dy / dist * step
    return True


# ==================== БАШНИ ====================

def find_target(t):
    for e in enemies:
        if e['hp'] <= 0:
            continue
        if distance(t['x'], t['y'], e['x'], e['y']) <= t['range']:
            return e
    return None


def update_towers(frame_factor):
    for t in towers:
        if t['cooldown'] > 0:
            t['cooldown'] -= frame_factor
            continue
        target = find_target(t)
        if target is None:
            continue
        bullets.append({
            'x': t['x'],
            'y': t['y'],
            'target': target,
            'speed': PROJECTILE_SPEED,
            'color': (255, 255, 100),
        })
        t['cooldown'] = TOWER_COOLDOWN


def update_projectiles(frame_factor):
    for i in range(len(bullets) - 1, -1, -1):
        b = bullets[i]
        target = b['target']
        if target['hp'] <= 0:
            bullets.pop(i)
            continue
        dx = target['x'] - b['x']
        dy = target['y'] - b['y']
        dist = math.sqrt(dx * dx + dy * dy)
        step = b['speed'] * frame_factor
        if dist < step:
            target['hp'] -= TOWER_DAMAGE
            bullets.pop(i)
        else:
            b['x'] += dx / dist * step
            b['y'] += dy / dist * step


# ==================== ГЛАВНАЯ ЛОГИКА ====================

def update(dt):
    global lives, kills, money, state
    global current_level, current_wave, enemies_spawned, spawn_timer
    global between_waves, pause_timer, between_levels, level_pause_timer

    if state != 'playing':
        return

    # Множитель для физики: 1.0 при 60 FPS, больше при меньшем FPS
    frame_factor = dt * 60

    # === Враги: удаляем мёртвых и дошедших ===
    for i in range(len(enemies) - 1, -1, -1):
        e = enemies[i]

        if e['hp'] <= 0:
            enemies.pop(i)
            kills += 1
            money += REWARD_KILL
            continue

        if not update_enemy(e, frame_factor):
            enemies.pop(i)
            lives -= 1
            if lives <= 0:
                state = 'lost'
                return

    # === Логика уровней и волн ===
    if between_levels:
        level_pause_timer -= dt
        if level_pause_timer <= 0:
            between_levels = False
            current_level += 1
            current_wave = 0
            enemies_spawned = 0
            spawn_timer = 0

    elif between_waves:
        pause_timer -= dt
        if pause_timer <= 0:
            between_waves = False
            current_wave += 1
            enemies_spawned = 0
            spawn_timer = 0

    else:
        waves = current_waves()
        wave = waves[current_wave]
        spawn_timer -= dt

        if spawn_timer <= 0 and enemies_spawned < wave['count']:
            enemies.append(make_enemy(wave))
            enemies_spawned += 1
            spawn_timer = wave['delay']

        # Волна закончилась — все враги кончились
        if enemies_spawned >= wave['count'] and len(enemies) == 0:
            if current_wave + 1 >= len(waves):
                # Последняя волна уровня
                if current_level + 1 >= len(LEVELS):
                    state = 'won'
                    return
                else:
                    between_levels = True
                    level_pause_timer = 5.0
                    lives += 5
                    money += 100
                    enemies.clear()
                    bullets.clear()
                    towers.clear()
            else:
                between_waves = True
                pause_timer = PAUSE_BETWEEN_WAVES

    # === Башни и снаряды ===
    update_towers(frame_factor)
    update_projectiles(frame_factor)


# ==================== ПЕРЕЗАПУСК ====================

def restart_game():
    global state, lives, money, kills
    global current_level, current_wave, enemies_spawned, spawn_timer
    global between_waves, pause_timer, between_levels, level_pause_timer

    state = 'playing'
    lives = START_LIVES
    money = START_MONEY
    kills = 0

    current_level = 0
    current_wave = 0
    enemies_spawned = 0
    spawn_timer = 0
    between_waves = False
    pause_timer = 0
    between_levels = False
    level_pause_timer = 0

    enemies.clear()
    bullets.clear()
    towers.clear()


# ==================== РАЗМЕЩЕНИЕ БАШЕН ====================

def tower_at(row, col):
    for t in towers:
        if t['row'] == row and t['col'] == col:
            return True
    return False


def is_cell_on_path(row, col):
    path = current_path()
    cell_x1 = col * CELL
    cell_y1 = row * CELL
    cell_x2 = cell_x1 + CELL
    cell_y2 = cell_y1 + CELL

    for i in range(len(path) - 1):
        x1, y1 = path[i]
        x2, y2 = path[i + 1]
        length = math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        steps = int(length / 4) + 1
        for s in range(steps + 1):
            t = s / steps
            px = x1 + (x2 - x1) * t
            py = y1 + (y2 - y1) * t
            if cell_x1 <= px < cell_x2 and cell_y1 <= py < cell_y2:
                return True
    return False


def can_place_tower(row, col):
    if state != 'playing':
        return False
    if between_levels:
        return False
    if row < 0 or row >= GRID_ROWS or col < 0 or col >= GRID_COLS:
        return False
    if tower_at(row, col):
        return False
    if is_cell_on_path(row, col):
        return False
    if money < TOWER_COST:
        return False
    return True


def place_tower(row, col):
    global money
    if not can_place_tower(row, col):
        return
    t = {
        'row': row,
        'col': col,
        'x': col * CELL + CELL // 2,
        'y': row * CELL + CELL // 2,
        'range': TOWER_RANGE,
        'cooldown': 0,
        'color': (100, 200, 255),
    }
    towers.append(t)
    money -= TOWER_COST


# ==================== РИСОВАНИЕ ====================

def render_text(surface, text, font, color, pos, center=False):
    surf = font.render(text, True, color)
    if center:
        rect = surf.get_rect(center=pos)
    else:
        rect = surf.get_rect(topleft=pos)
    surface.blit(surf, rect)


def draw_path(screen):
    path = current_path()
    for i in range(len(path) - 1):
        x1, y1 = path[i]
        x2, y2 = path[i + 1]
        pygame.draw.line(screen, (90, 90, 120),
                         (int(x1), int(y1)), (int(x2), int(y2)), 3)
    for (x, y) in path:
        pygame.draw.circle(screen, (120, 120, 160), (int(x), int(y)), 6)


def draw_enemy(screen, e):
    cx, cy = int(e['x']), int(e['y'])
    r = e['size'] // 2
    pygame.draw.circle(screen, e['color'], (cx, cy), r)
    pygame.draw.circle(screen, (255, 255, 255), (cx, cy), r, 1)

    bar_w = e['size']
    bar_h = 4
    bar_x = int(e['x'] - bar_w / 2)
    bar_y = int(e['y'] - r - 8)
    pygame.draw.rect(screen, (60, 20, 20), (bar_x, bar_y, bar_w, bar_h))
    hp_ratio = max(0, e['hp'] / e['max_hp'])
    pygame.draw.rect(screen, (100, 255, 100),
                     (bar_x, bar_y, int(bar_w * hp_ratio), bar_h))


def draw_tower(screen, t):
    x1 = t['x'] - CELL // 2 + 4
    y1 = t['y'] - CELL // 2 + 4
    size = CELL - 8
    pygame.draw.rect(screen, t['color'], (x1, y1, size, size))
    pygame.draw.rect(screen, (255, 255, 255), (x1, y1, size, size), 1)
    pygame.draw.circle(screen, (30, 30, 60), (t['x'], t['y']), 6)


def draw_bullet(screen, b):
    cx, cy = int(b['x']), int(b['y'])
    pygame.draw.circle(screen, b['color'], (cx, cy), PROJECTILE_RADIUS)
    pygame.draw.circle(screen, (255, 255, 255), (cx, cy), PROJECTILE_RADIUS, 1)


def draw_hover_cell(screen):
    if state != 'playing':
        return
    if between_levels:
        return
    mx, my = pygame.mouse.get_pos()
    col = mx // CELL
    row = my // CELL
    if row < 0 or row >= GRID_ROWS or col < 0 or col >= GRID_COLS:
        return
    x = col * CELL
    y = row * CELL
    if can_place_tower(row, col):
        color = (100, 255, 100)
        cx = col * CELL + CELL // 2
        cy = row * CELL + CELL // 2
        pygame.draw.circle(screen, (60, 120, 60), (cx, cy), TOWER_RANGE, 1)
    else:
        color = (255, 80, 80)
    pygame.draw.rect(screen, color, (x + 1, y + 1, CELL - 2, CELL - 2), 2)


def draw_hud(screen, fonts):
    render_text(screen, f"Деньги: {money}", fonts['medium'], (255, 215, 0), (10, 10))
    render_text(screen, f"Жизни: {lives}", fonts['normal'], (255, 255, 255), (10, 40))
    render_text(screen, f"Убито: {kills}", fonts['normal'], (255, 255, 255), (10, 65))
    render_text(screen, f"Уровень: {current_level + 1}/{len(LEVELS)}",
                fonts['normal'], (255, 200, 100), (10, 90))
    render_text(screen, f"Волна: {current_wave + 1}/{len(current_waves())}",
                fonts['small'], (255, 255, 255), (10, 115))
    render_text(screen, f"Башен: {len(towers)}",
                fonts['small'], (180, 180, 180), (10, 140))
    # Debug-информация
    render_text(screen, f"state: {state}",
                fonts['tiny'], (255, 100, 100), (10, 165))
    render_text(
        screen,
        f"enemies: {len(enemies)} spawn: {enemies_spawned}/{current_waves()[current_wave]['count']}",
        fonts['tiny'], (150, 150, 150), (10, 185)
    )


def draw(screen, fonts):
    screen.fill(current_bg())

    draw_path(screen)
    draw_hover_cell(screen)

    for t in towers:
        draw_tower(screen, t)
    for e in enemies:
        draw_enemy(screen, e)
    for b in bullets:
        draw_bullet(screen, b)

    draw_hud(screen, fonts)

    # === Объявление следующей волны ===
    if state == 'playing' and between_waves:
        seconds = math.ceil(pause_timer)
        render_text(screen, f"ВОЛНА {current_wave + 2}",
                    fonts['title'], (255, 255, 0),
                    (WIDTH // 2, HEIGHT // 2 - 40), center=True)
        render_text(screen, f"через {seconds}...",
                    fonts['xl'], (255, 255, 255),
                    (WIDTH // 2, HEIGHT // 2 + 30), center=True)

    # === Объявление следующего уровня ===
    if state == 'playing' and between_levels:
        seconds = math.ceil(level_pause_timer)
        render_text(screen, f"УРОВЕНЬ {current_level + 2}",
                    fonts['title'], (255, 215, 0),
                    (WIDTH // 2, HEIGHT // 2 - 40), center=True)
        render_text(screen, f"через {seconds}...",
                    fonts['xl'], (255, 255, 255),
                    (WIDTH // 2, HEIGHT // 2 + 30), center=True)
        render_text(screen, "+5 жизней, +100 денег",
                    fonts['medium'], (100, 255, 100),
                    (WIDTH // 2, HEIGHT // 2 + 90), center=True)

    # === Экран победы ===
    if state == 'won':
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))

        render_text(screen, "ПОБЕДА!", fonts['mega'], (255, 215, 0),
                    (WIDTH // 2, HEIGHT // 2 - 60), center=True)
        render_text(screen, f"Все {len(LEVELS)} уровня пройдены!",
                    fonts['large'], (255, 255, 255),
                    (WIDTH // 2, HEIGHT // 2), center=True)
        render_text(screen, f"Убито врагов: {kills}",
                    fonts['large'], (255, 255, 255),
                    (WIDTH // 2, HEIGHT // 2 + 40), center=True)
        render_text(screen, f"Осталось жизней: {lives}",
                    fonts['medium'], (255, 255, 255),
                    (WIDTH // 2, HEIGHT // 2 + 75), center=True)
        render_text(screen, "Нажми R для новой игры",
                    fonts['medium'], (255, 255, 0),
                    (WIDTH // 2, HEIGHT // 2 + 130), center=True)

    # === Экран поражения ===
    if state == 'lost':
        overlay = pygame.Surface((WIDTH, HEIGHT))
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))

        render_text(screen, "ИГРА ОКОНЧЕНА", fonts['xxl'], (255, 0, 0),
                    (WIDTH // 2, HEIGHT // 2 - 60), center=True)
        render_text(screen, f"Убито врагов: {kills}",
                    fonts['large'], (255, 255, 255),
                    (WIDTH // 2, HEIGHT // 2 + 10), center=True)
        render_text(screen, f"Уровень: {current_level + 1}/{len(LEVELS)}",
                    fonts['medium'], (255, 255, 255),
                    (WIDTH // 2, HEIGHT // 2 + 50), center=True)
        render_text(screen, "Нажми R для новой игры",
                    fonts['medium'], (255, 255, 0),
                    (WIDTH // 2, HEIGHT // 2 + 110), center=True)


# ==================== ГЛАВНЫЙ ЦИКЛ ====================

async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Tower Defense")
    clock = pygame.time.Clock()

    # Шрифты (встроенный freesansbold поддерживает кириллицу)
    fonts = {
        'tiny':   pygame.font.Font(None, 12),
        'small':  pygame.font.Font(None, 16),
        'normal': pygame.font.Font(None, 18),
        'medium': pygame.font.Font(None, 22),
        'large':  pygame.font.Font(None, 28),
        'xl':     pygame.font.Font(None, 34),
        'xxl':    pygame.font.Font(None, 44),
        'title':  pygame.font.Font(None, 56),
        'mega':   pygame.font.Font(None, 64),
    }

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        # Ограничим dt сверху, чтобы при лагах враги не телепортировались
        if dt > 0.1:
            dt = 0.1

        # ---------- События ----------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and state == 'playing':
                    mx, my = event.pos
                    col = mx // CELL
                    row = my // CELL
                    place_tower(row, col)

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and state in ('won', 'lost'):
                    restart_game()

        # ---------- Логика ----------
        update(dt)

        # ---------- Рисование ----------
        draw(screen, fonts)
        pygame.display.flip()

        # Обязательно для pygbag — отдать управление браузеру
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())